<footer id="bottom">
    <nav style="" class="navbar navbar-dark bg-dark shadow-sm fixed-bottom">
        <div class="inner" style="text-align: center; width: 100%">
            <a class="nav-item" style="font-size: 15px" href="#">Contact : mon email...</a>
        </div>
    </nav>
</footer>
