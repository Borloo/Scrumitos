<nav style="" class="navbar navbar-dark bg-dark shadow-sm fixed-top">
    <div style="text-align: center; width: 100%">
        <a class="navbar-brand" style="font-size: 30px" href="index.php">
            Charte Graphique en Bootstrap
		</a>
    </div>
</nav>

